const s="/assets/logo-6VIUaQKR.png";export{s as _};
