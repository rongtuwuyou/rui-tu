const s="/assets/background-Bthat39x.jpg";export{s as _};
